public class Strong_Knight extends Knight{
    @Override
    public float challenge() {
        return 20.0f;
    }

    @Override
    public String name() {
        return "Strong Knight";
    }
}
