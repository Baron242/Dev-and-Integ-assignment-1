//implements Weapon
public class Sword implements Weapon{
    @Override
    public String weapon() {
        return "Sword";
    }
}
