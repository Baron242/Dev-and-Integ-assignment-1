//implements Weapon
public class FireBreath implements Weapon{
    @Override
    public String weapon() {
        return "Fire Breath";
    }
}
