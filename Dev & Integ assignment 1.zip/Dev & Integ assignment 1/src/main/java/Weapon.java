//This is a part of the parent class.
public interface Weapon {
    public String weapon();
}
