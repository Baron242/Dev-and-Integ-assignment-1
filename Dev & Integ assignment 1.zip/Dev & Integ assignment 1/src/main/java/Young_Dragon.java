//extends Dragon
public class Young_Dragon extends Dragon {
    @Override
    public float challenge() {
        return 3.7f;
    }

    @Override
    public String name() {
        return "Young Dragon";
    }
}
