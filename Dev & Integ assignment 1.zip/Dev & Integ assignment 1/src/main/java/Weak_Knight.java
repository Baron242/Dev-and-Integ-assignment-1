public class Weak_Knight extends Knight {
    @Override
    public float challenge() {
        return 2.5f;
    }

    @Override
    public String name() {
        return "Injured Knight";
    }
}
