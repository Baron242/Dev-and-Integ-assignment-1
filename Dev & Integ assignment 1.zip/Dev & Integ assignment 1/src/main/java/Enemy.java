//This is a part of the parent class.
public interface Enemy {
    public String name();
    public Weapon weapon();
    public float challenge();
}
