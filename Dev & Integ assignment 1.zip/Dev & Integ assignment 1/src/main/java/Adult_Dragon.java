//extends Dragon
public class Adult_Dragon extends Dragon {
    @Override
    public float challenge() {
        return 27.0f;
    }

    @Override
    public String name() {
        return "Adult Dragon";
    }
}
